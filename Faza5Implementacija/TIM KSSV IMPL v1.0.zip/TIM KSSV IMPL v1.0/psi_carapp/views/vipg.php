<form name="vipgform" method="POST" action="<?php echo $_SERVER['PHP_SELF']; ?>?controller=admin&action=giveVip">
    <h1>Dodeli VIP</h1>
    <br>
    <br>
    <br>
    <table>
        <tr>
            <td>
                Unesite korisnicko ime za<br>
                dodelu VIP statusa:
            </td>
            <td>
                <input type="text" name="username" value="<?php if(isset($username)) echo $username; ?>"/>
            </td>
        </tr>
        <tr>
            <td colspan="2">
                <font color='red'><?php if(isset($messageUsername)) echo $messageUsername; ?></font>
            </td>
        </tr>
        <tr>
            <td colspan="2">
                <br>
            </td>
        </tr>
        <tr>
            <td>
                
            </td>
            <td>
                <input type='submit' name="submit" value="Dodeli"/>
            </td>
        </tr>
    </table>
</form>
