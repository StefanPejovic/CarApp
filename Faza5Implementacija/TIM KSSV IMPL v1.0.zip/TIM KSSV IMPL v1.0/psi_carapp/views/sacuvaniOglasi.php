<?php
foreach($savedAd as $ad){
    echo ' Sledeci::: ';
    echo $ad->marka;
    echo '  ';
    echo $ad->model;
    echo '  ';
    echo $ad->godiste; 
    echo '  ';
    echo $ad->kilometraza;
    echo '  ';
    echo $ad->snaga; 
    echo '  ';
    echo $ad->menjac;
    echo '  ';
    echo $ad->gorivo;

}

