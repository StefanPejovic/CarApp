<html>
    <head>
        <title>
            CarApp
        </title>
    </head>
    <body>
        <h1>VIP</h1>
        <div style="float: left">
            <a href="?controller=vip&action=logout">Odjavi se</a>
        </div>
        <div style="float: right">
            <a href="?controller=vip&action=myAd">Moji oglasi</a>
        </div>
        <div style="float: right">
            <br>
            <a href="?controller=vip&action=savedAd">Sacuvani oglasi</a>
        </div>
    </body>
</html>

