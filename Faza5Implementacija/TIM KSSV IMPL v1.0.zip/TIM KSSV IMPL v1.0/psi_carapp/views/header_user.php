<html>
    <head>
        <title>
            CarApp
        </title>
    </head>
    <body>
        <h1>Obican</h1>
        <div style="float: left">
            <a href="?controller=user&action=logout">Odjavi se</a>
        </div>
        <div style="float: right">
            <a href="?controller=user&action=myAd">Moji oglasi</a>
        </div>
        <div style="float: right">
            <br>
            <a href="?controller=user&action=savedAd">Sacuvani oglasi</a>
        </div>
    </body>
</html>

