<!--STEFAN MLADENOVIC
    php delove dodali MIHAJLO KRPOVIC, STEFAN PEJOVIC
-->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel='stylesheet' type='text/css' href='./views/FAQ1/fajlovi/bootstrap.min.css'>
    <link rel='stylesheet' type='text/css' href='./views/FAQ1/faq1.css'>

    <script src='./views/FAQ1/fajlovi/bootstrap.min.js'></script>
    
    <link rel="stylesheet" type="text/css" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">

    <style>
        .pagination {
          display: inline-block;
        }
        
        .pagination a {
          color: black;
          float: left;
          padding: 8px 16px;
          text-decoration: none;
        }
        </style>
</head>
<body style="background-color:lightblue;">
    <div class='container+fluid'>
        <div class='row'>
            <div class='col-sm-11 center'>
                <nav class='navbar navbar-expand-sm lightgraybg'>
                    <h2 style="display: inline" >FAQ </h2>
                    

            </div>        
            <div class='col-sm-1'>
                    <ul class='navbar-nav'>
                        <li class='nav-item'>
                            <a href="?controller=guest&action=index"><input type="button" name='button' class=' btn btn-light' value="Nazad"></a>
                        </li>
                    </ul>
                </nav>

                
            </div>
        </div>
        <div class='row'>
           <div class='col-lg-12  center'>

            <div class="alert alert-success alert-dismissible">
                <button type="button" name='button' class="close" datadismiss="alert">&times;</button>
                <strong>Pitanje</strong> Kako mogu koristiti CarApp?
               </div>

               <div class="alert alert-danger alert-dismissible">
                <button type="button" name='button' class="close" datadismiss="alert">&times;</button>
                <strong>Odgovor</strong> Mozete se prijaviti na sajt ukoliko ste prethodno registrovani
               </div>

               <div class="alert alert-success alert-dismissible">
                <button type="button" name='button' class="close" datadismiss="alert">&times;</button>
                <strong>Pitanje</strong> Kako se registrujem?
               </div>

               <div class="alert alert-danger alert-dismissible">
                <button type="button" name='button' class="close" datadismiss="alert">&times;</button>
                <strong>Odgovor</strong> Registrujete se tako sto odaberete dugme za registraciju i nakon toga se prebacujete na stranicu za registrovanje. Nakon sto popunite sva polja, kliko na dugme saljete svoj zahtev administratoru
               </div>

               <div class="alert alert-success alert-dismissible">
                <button type="button" name='button' class="close" datadismiss="alert">&times;</button>
                <strong>Pitanje</strong> Kakva je razlika izmedju VIP i obicnog korisnika?
               </div>

               <div class="alert alert-danger alert-dismissible">
                <button type="button" name='button' class="close" datadismiss="alert">&times;</button>
                <strong>Odgovor</strong> VIP korisnik ima mogucnosti pracenja oglasa. Vesti za izabrane oglase poput popusta i slicno mu stizu na mail. Takodje svi VIP oglasi su istaknuti pre obicnih.
               </div>
               
               <div class="pagination">
                <a href="#">&laquo;</a>
                <a href="#">1</a>
                <a href="#">2</a>
                <a href="#">3</a>
                <a href="#">&raquo;</a>
              </div>
               



               
           </div>

           
        </div>

        
        
        
    </div>
    
</body>
</html>