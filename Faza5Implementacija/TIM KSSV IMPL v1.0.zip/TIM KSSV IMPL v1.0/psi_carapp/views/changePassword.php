<form name="changepasswordform" method="POST" action="<?php echo $_SERVER['PHP_SELF']; ?>?controller=guest&action=changePassword">
    <table>
        <tr>
            <td colspan="2" style="text-align: center">
                <h1>Promena lozinke</h1>
            </td>
        </tr>
        <tr>
            <td>
                Korisnicko ime:
            </td>
            <td>
                <input type="text" name="username" value="<?php if(isset($username)) echo $username; ?>"/>
            </td>
        </tr>
        <tr>
            <td colspan="2">
                <font color='red'><?php if(isset($messageUsername)) echo $messageUsername; ?></font>
            </td>
        </tr>
        <tr>
            <td>
                Stara lozinka:
            </td>
            <td>
                <input type="password" name="oldPassword" value="<?php if(isset($oldPassword)) echo $oldPassword; ?>"/>
            </td>
        </tr>
        <tr>
            <td colspan="2">
                <font color='red'><?php if(isset($messageOldPassword)) echo $messageOldPassword; ?></font>
            </td>
        </tr>
        <tr>
            <td>
                Nova lozinka:
            </td>
            <td>
                <input type="password" name="newPassword" value="<?php if(isset($newPassword)) echo $newPassword; ?>"/>
            </td>
        </tr>
        <tr>
            <td colspan="2">
                <font color='red'><?php if(isset($messageNewPassword)) echo $messageNewPassword; ?></font>
            </td>
        </tr>
        <tr>
            <td>
                Ponovljena lozinka:
            </td>
            <td>
                <input type="password" name="newnewPassword" value="<?php if(isset($newnewPassword)) echo $newnewPassword; ?>"/>
            </td>
        </tr>
        <tr>
            <td colspan="2">
                <font color='red'><?php if(isset($messageNewNewPassword)) echo $messageNewNewPassword; ?></font>
            </td>
        </tr>
        <tr>
            <td colspan="2">
                <br>
            </td>
        </tr>
        <tr>
            <td colspan="2" style="text-align: center">
                <input type='submit' name="submitp" value="Promeni"/>
            </td>
        </tr>
    </table>
</form>
