<form name="brisanjeform" method="POST" action="<?php echo $_SERVER['PHP_SELF']; ?>?controller=admin&action=deleteAd">
    <h1>Brisanje oglasa</h1>
    <br>
    <br>
    <br>
    <table>
        <tr>
            <td>
                Unesite ID oglasa koji brisete:
            </td>
            <td>
                <input type="text" name="id" value="<?php if(isset($id)) echo $id; ?>"/>
            </td>
        </tr>
        <tr>
            <td colspan="2">
                <font color='red'><?php if(isset($messageId)) echo $messageId; ?></font>
            </td>
        </tr>
        <tr>
            <td colspan="2">
                <br>
            </td>
        </tr>
        <tr>
            <td>
                
            </td>
            <td>
                <input type='submit' name="submit" value="Obrisi"/>
            </td>
        </tr>
    </table>
</form>
