<form name="viptform" method="POST" action="<?php echo $_SERVER['PHP_SELF']; ?>?controller=admin&action=takeVip">
    <h1>Oduzmi VIP</h1>
    <br>
    <br>
    <br>
    <table>
        <tr>
            <td>
                Unesite korisnicko ime za<br>
                oduzimanje VIP statusa:
            </td>
            <td>
                <input type="text" name="username" value="<?php if(isset($username)) echo $username; ?>"/>
            </td>
        </tr>
        <tr>
            <td colspan="2">
                <font color='red'><?php if(isset($messageUsername)) echo $messageUsername; ?></font>
            </td>
        </tr>
        <tr>
            <td colspan="2">
                <br>
            </td>
        </tr>
        <tr>
            <td>
                
            </td>
            <td>
                <input type='submit' name="submit" value="Oduzmi"/>
            </td>
        </tr>
    </table>
</form>

