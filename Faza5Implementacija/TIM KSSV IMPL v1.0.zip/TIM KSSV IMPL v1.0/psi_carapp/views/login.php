<form name="loginform" method="POST" action="<?php echo $_SERVER['PHP_SELF']; ?>?controller=guest&action=login">
    <table>
        <tr>
            <td colspan="2" style="text-align: center">
                <h1>Prijava</h1>
            </td>
        </tr>
        <tr>
            <td>
                Korisnicko ime:
            </td>
            <td>
                <input type="text" name="username" value="<?php if(isset($username)) echo $username; ?>"/>
            </td>
        </tr>
        <tr>
            <td colspan="2">
                <font color='red'><?php if(isset($messageUsername)) echo $messageUsername; ?></font>
            </td>
        </tr>
        <tr>
            <td>
                Lozinka:
            </td>
            <td>
                <input type="password" name="password" value="<?php if(isset($password)) echo $password; ?>"/>
            </td>
        </tr>
        <tr>
            <td colspan="2">
                <font color='red'><?php if(isset($messagePassword)) echo $messagePassword; ?></font>
            </td>
        </tr>
        <tr>
            <td colspan="2">
                <br>
            </td>
        </tr>
        <tr>
            <td colspan="2" style="text-align: center">
                <input type='submit' name="submit" value="Prijavi se"/>
            </td>
        </tr>
    </table>
</form>

