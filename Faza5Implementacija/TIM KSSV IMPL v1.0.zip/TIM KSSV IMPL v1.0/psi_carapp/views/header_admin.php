<html>
    <head>
        <title>
            CarApp
        </title>
    </head>
    <body>
        <h1>Admin</h1>
        <div style="float: left">
            <a href="?controller=admin&action=logout">Odjavi se</a>
        </div>
        <div style="float: right">
            <a href="?controller=admin&action=giveVipShow">Dodeli VIP</a>
        </div>
        <div style="float: right">
            <br>
            <br>
            <a href="?controller=admin&action=takeVipShow">Oduzmi VIP</a>
        </div>
        <div style="float: right">
            <br>
            <br>
            <br>
            <br>
            <a href="?controller=admin&action=banUserShow">Banuj korisnika</a>
        </div>
        <div style="float: right">
            <br>
            <br>
            <br>
            <br>
            <br>
            <br>
            <a href="?controller=admin&action=deleteAdShow">Obrisi oglas</a>
        </div>
    </body>
</html>

