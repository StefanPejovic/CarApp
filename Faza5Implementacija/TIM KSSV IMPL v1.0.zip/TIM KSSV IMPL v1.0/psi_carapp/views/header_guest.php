<html>
    <head>
        <title>
            CarApp
        </title>
    </head>
    <body>
        <div style="float: right">
            <a href="?controller=guest&action=loginShow">Uloguj se</a>
        </div>
        <div style="float: left">
            <a href="?controller=guest&action=changePasswordShow">Promeni lozinku</a>
        </div>
    </body>
</html>
